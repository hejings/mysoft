#!/bin/bash
#Author: haodongzhang
#Date: 08/01/2020
#Version: 1.0
#Function: 快速制作不同平台deb安装包(仅限内部HA使用)，如需定制请联系zhanghaodong@kylinos.cn


clear
function cecho {
	echo -e "\033[$1m$2\033[0m"
	#fonts color: 31-red;32-green;36-deepgreen;34-blue;
}
[ -d ~/myscript ] || sudo mkdir ~/myscript

###########################选择菜单##################################
function menu {
read -p "请输入即将要制作的包名：" softname
read -p "请输入即将要制作的包的版本：" version

cat <<EOF
*************************************************************
	1) mips64el platform
	2) amd64 platform
	3) i386 platform
	4) arm64 platform
	5) exit
*************************************************************
EOF

read -p "请选择你要制作什么平台的安装包：" platform
case $platform in
	1)
		platform=mips64el;;
	2)
		platform=amd64;;
	3)
		platform=i386;;
	4)
		platform=arm64;;
	5)
		cecho 32 Byebye
		exit;;
	*)
		cecho 31 "选择有误，程序将退出，请重新选择！"
		exit;;
esac

cat <<EOF
***********************************************************
	1) 安装在/opt/ha/lib/ocf/resource.d/heartbeat/下
	2）安装在/opt/ha/usr/lib/ocf/resource.d/heartbeat/下
	3）自定义
	4）exit
EOF
read -p "你希望此安装包安装在哪里：" choice
case $choice in 
	1)
		sudo mkdir -p $softname/opt/ha/lib/ocf/resource.d/heartbeat
		softpath=$softname/opt/ha/lib/ocf/resource.d/heartbeat;;
	2)
		sudo mkdir -p $softname/opt/ha/usr/lib/ocf/resource.d/heartbeat
		softpath=$softname/opt/ha/usr/lib/ocf/resource.d/heartbeat/;;
	3)
		read -p "请手动敲打你想要安装在哪个目录下：" wheredir
		softpath=$softname/$wheredir;;
	4)
		cecho 32 Byebye
		exit;;
	*)
		cecho 31 "选择有误，程序将退出，请重新选择！"
		exit;;
esac
}

###################################编写control文件#####################################
function make-control {
sudo mkdir -p $softname/DEBIAN
sudo touch $softname/DEBIAN/{control,postinst,preinst,postrm,prerm}
sudo chmod  -R 0775 $softname/DEBIAN/{postinst,preinst,postrm,prerm}
sudo cat >$softname/DEBIAN/control<<EOF
Package: $softname
Source: Unknown
Version: $version-kylin
Architecture: $platform
Maintainer: haodong zhang <conquer929@qq.com>
Installed-Size: Unknown
Depends: Unknown
Recommends: Unknown
Suggests: Unknown
Conflicts: Unknown
Breaks: Unknown
Replaces: Unknown
Provides: Unknown
Section: Unknown
#Priority: Unknown
#Multi-Arch: Unknown
Homepage: Unknown
Description: This installation package is for internal use only,such as external use will not bear any responsibility. The installation package is mainly used for ha debugging of secret-related machines,and no responsibility is assumed for the use of external machines.
EOF
}

####################################主程序编包#########################################
function make-soft {
sudo mkdir -p $softpath
sudo cp -rf myscript/* $softpath
sudo [ -d build ] || sudo mkdir build
sudo dpkg -b $softname build
cecho 32 正在制作$softname"_"$version-kylin"_"$platform.deb...... && sleep 3
[ $? -eq 0 ] && cecho 32 安装包制作完成，已放在当前build目录下，请查看！|| cecho 31 "安装包制作失败，请从新运行程序！"
rm -rf $softname
}

cecho
menu
make-control
make-soft



